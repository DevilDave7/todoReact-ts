import { TodoAction } from '../Actions/todo.action';
import { getTasks } from '../Helpers/httpRequest';
import { TodoState } from '../Interfaces/todo.interface';

export const ToDoReducer = (state:TodoState, {type,payload}:TodoAction):TodoState => {
  switch(type){
    case 'getTasks':
      getTasks().then(data=>{
        if(!data.error) return {
          ...state,
          Error: data.error,
          IsLoading: false
        }

        return {
          Tasks: data.data,
          IsLoading: false
        }
      }).catch(err=>{
        return {
          ...state,
          Error:err,
          IsLoading: false
        }
      })
    break;

    case 'AddTask':
      return {
        ...state,
        Tasks: [payload.value,...state.Tasks]
      }

    default:
      return state;
  }
}
