import { Table } from "antd"
import { Task } from "../Interfaces/task.interface"

interface Props{
  data?: Task[],
  loading: boolean
}


export const TableTodo = ({data,loading=true}:Props) => {

  return (
    <Table
      dataSource={data}
      scroll={{ y: 'max-content' , x: 1350 }}
      loading={loading}
      size="large"
      style={{height:'auto'}}
    />
  )
}
