import { Task } from '../Interfaces/task.interface';

export type TodoAction =
  |{type: 'getTasks', payload?:{value:0}}
  |{type: 'AddTask', payload:{value:Task}}

export const getAllTasks = ():TodoAction=>(
  {type: 'getTasks'}
)

export const AddTask = (value:Task):TodoAction=>(
  {type: 'AddTask', payload:{value}}
)