import axios from "axios"

const BASE_URI = 'https://jsonplaceholder.typicode.com/todos';
const headers = {
  "Content-Type": "Application/json"
}


export const getTasks = async() => {
  return await axios.get(BASE_URI,{headers})
    .then(data=>{
      console.log({data})
      return ({
        code:200,
        data,
        error:null
      });
    }).catch(err=>{
      console.error(err);
      return ({code:505,error:err,data:[]})
    })
}
