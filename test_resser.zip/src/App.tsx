import { useEffect, useReducer } from "react"
import { ToDoReducer } from "./Reducer/ToDoReducer"
import { getAllTasks } from './Actions/todo.action';
import { TodoState } from "./Interfaces/todo.interface";
import { TableTodo } from './Components/TableTodo';

function App() {

  const INITIAL_STATE: TodoState={
    Tasks: [],
    IsLoading: true,
    Error: null
  }

  const [todo, dispatch] = useReducer(ToDoReducer, INITIAL_STATE)

  useEffect(() => {
    dispatch( getAllTasks() );
  }, [])
  

  return (
    <>
      <TableTodo data={todo.Tasks} loading={todo.IsLoading}/>
    </>
  )
}

export default App
